public class login {
  public String dbID = "jdbc:mysql://localhost:3306/MortgageManagementSystem";
  public String userID = "root";
  public String pw = "Zhang1032002.";

  public login() {
  }
}
