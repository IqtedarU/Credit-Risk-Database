public class display {
  public display() { }

  public String main =                    "-------------------- Welcome to MMS --------------------\n" + 
                                          " Enter [l] to login\n" + 
                                          " Enter [q] to quit the program";

  public String loginUsername =           "-------------------- Login Page ------------------------\n" +
                                          " Enter [l] to go back to main page\n" +
                                          " Please enter your username: ";

  public String loginPW =                 "\n Enter [l] to go back to main page\n" +
                                          " Please enter your password: ";

  public String regUsername =             "-------------------- Registration Page -----------------\n" + 
                                          " Enter [l] to to go back to main page\n" + 
                                          " Please enter your username: ";

  public String regPW =                   "\n Enter [l] to to go back to main page\n" + 
                                          " Please enter your password: ";

  public String lenderMenu =              "-------------------- Lender Menu -----------------------\n" +
                                          " Enter [c] to get contact information on your borrowers\n" + 
                                          " Enter [e] to edit your contact information\n" +
                                          " Enter [m] to get all your mortgages\n" + 
                                          " Enter [l] to log out\n" + 
                                          " Enter [q] to quit the program";

  public String borrowerMenu =            "-------------------- Borrower Menu ---------------------\n" +
                                          " Enter [b] to see your payments\n" + 
                                          " Enter [s] to see your credit score\n" + 
                                          " Enter [p] to look up properties\n" + 
                                          " Enter [c] to get contact information on your lenders\n" + 
                                          " Enter [e] to edit your contact information\n" +
                                          " Enter [d] to get all your document information\n" + 
                                          " Enter [m] to get all your mortgages\n" + 
                                          " Enter [l] to log out\n" + 
                                          " Enter [q] to to quit the program";

  public String ecTitle =                 "          --------------- Your Contacts ----------------\n";       // new bit after presentation start
  public String ecMenu =                  " Enter [b] to stop editing\n" + 
                                          " Or enter the number next to the item you wish to select\n" + 
                                          " Or enter the new email or phone number you wish to add\n";

  public String ecMenu2 =                 " Enter [b] to stop editing\n" +
                                          " Or enter [z] to delete selected item\n" + 
                                          " Or enter the new value: ";                                        // new bit after presentation end

  public String propertyPage =            "          --------------- Property Page ----------------\n" +
                                          " Enter [-] to skip a filter\n" +
                                          " Please Enter the state: ";
  public String pp2 =                     " Please Enter the market value upperbound: ";
  public String pp3 =                     " Please Enter the market value lowerbound: ";
  public String pp4 =                     " Please Enter the year built upperbound: ";
  public String pp5 =                     " Please Enter the year built lowerbound: ";
  public String pp6 =                     " Please Enter the property type: ";
}
