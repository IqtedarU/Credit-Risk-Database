import java.sql.*;
import java.text.*;
import java.util.*;

public class MMS { // set up
    static login signIn = new login();
    static String user = "";
    static display ui = new display();
    static Scanner key = new Scanner(System.in);
    static String input = "";
    static boolean noQuit = true;
    static NumberFormat money = NumberFormat.getCurrencyInstance();

    public static void main(String[] args) throws Exception {
        System.out.println("\n\n\nStarting program . . .");
        mainPage();
    }

    // --------------------------------------------------------------------------------------------
    public static void mainPage() {
        while (noQuit) {
            System.out.println("\n\n\n" + ui.main); // display menu
            input = key.next();

            switch (input) {
                case "q": // if q, end program
                    noQuit = false;
                    break;
                case "l": // if l, preceed to login page
                    loginPage();
                    break;
                default: // anything else is invalid, try again
                    break;
            }
        }
    };

    // --------------------------------------------------------------------------------------------
    public static void loginPage() {// connect to the database
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            ResultSet rs;
            PreparedStatement ps;
            boolean badUsername = true;
            boolean badpw = true;
            String password = "";
            String name = "";
            String type = "";

            while (noQuit && badUsername) {
                System.out.println("\n\n\n" + ui.loginUsername); // display menu for Username
                input = key.next();

                if (input.equals("l")) { // if want to go back to main page
                    mainPage();
                }

                ps = c.prepareStatement("select password from User where username like ?");
                ps.setString(1, input);
                rs = ps.executeQuery();

                while (rs.next()) { // Save pw and user
                    user = input;
                    password = (rs.getString(1));
                    badUsername = false;
                }
            }

            while (noQuit && badpw) {
                System.out.println(ui.loginPW); // display menu for password
                input = key.next(); // example: Leo -> bhfe79 and Draho -> br54re56

                if (input.equals("l")) { // if want to go back to main page
                    mainPage();
                }

                if (password.equals(input)) {
                    badpw = false;
                }
            }

            // check if user is borrower or lender
            ps = c.prepareStatement("select nameFirst, namelast, userType from User where username like ?");
            ps.setString(1, user);
            rs = ps.executeQuery();

            while (rs.next()) { // get full name and type
                name = rs.getString(1) + " " + rs.getString(2);
                type = rs.getString(3);
            }

            System.out.println("\n\n\n" + "Welcome " + type + " " + name);
            if (type.equals("lender")) {
                lenderPage();
            } else {
                borrowerPage();
            }

        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    // ---------------------------------------------------------------------------------------------
    public static void lenderPage() {
        boolean noLogout = true;
        while (noQuit && noLogout) {
            // connect to the database
            try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
                ResultSet rs;
                PreparedStatement ps;
                System.out.println("\n\n\n" + ui.lenderMenu); // display menu for lender
                input = key.next();
                switch (input) {
                    case "e":
                        EditContact();
                        break;
                    case "c":
                        ps = c.prepareStatement("Select borrower.nameFirst, borrower.nameLast, UserPhone.phoneNum, " +
                                "UserEmail.email " +
                                "From borrower Inner Join UserEmail on borrower.username=UserEmail.username " +
                                "Inner Join UserPhone on borrower.username = UserPhone.username " +
                                "Where borrower.borrowerID in (Select borrowerID from lender Inner Join Mortgage " +
                                "on lender.lenderID=Mortgage.lenderID where lender.username=?)");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Borrower name: " + rs.getString(1) + " " + rs.getString(2) +
                                    "\n Phone: " + rs.getLong(3) +
                                    "\n Email: " + rs.getString(4));
                        }
                        break;
                    case "m":
                        ps = c.prepareStatement("select mortgageID, totalLoan, startDate, endDate, InterestRate, " +
                                "FreqOfInstallments, mortgageStatus, borrowerID, propertyID " +
                                "from lender join mortgage on lender.lenderID = mortgage.lenderID " +
                                "where username like ?");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n MortgageID: " + rs.getInt(1) +
                                    "\n Status: " + rs.getString(7) +
                                    "\n Total Loan: " + money.format(rs.getDouble(2)) +
                                    "\n Interest Rate: " + rs.getInt(5) + "%" +
                                    "\n Frequency Of Installments: " + rs.getString(6) +
                                    "\n Start Date: " + rs.getString(3) +
                                    "\n End Date: " + rs.getString(4) +
                                    "\n Property ID: " + rs.getString(9) +
                                    "\n Borrower ID: " + rs.getInt(8));
                        }
                        break;
                    case "l":
                        noLogout = false;
                        mainPage();
                        break;
                    case "q":
                        noQuit = false;
                        break;
                    default:
                        break;
                }

            } catch (SQLException sqle) {
                System.out.println("SQLException : " + sqle);
            }
        }
    }

    // ---------------------------------------------------------------------------------------------
    public static void borrowerPage() {
        boolean noLogout = true;
        while (noQuit && noLogout) {
            // connect to the database
            try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
                ResultSet rs;
                PreparedStatement ps;
                System.out.println("\n\n\n" + ui.borrowerMenu); // display menu for borrower
                input = key.next();
                switch (input) {
                    case "e":
                        EditContact();
                        break;
                    case "b":
                        ps = c.prepareStatement("Select dateOfPayment,amountPaid, StatusOfPayment,paymentType " +
                                "from Payment inner Join Borrower on Payment.borrowerID=Borrower.borrowerID " +
                                "where Borrower.username=?");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Date: " + rs.getString(1) +
                                    "\n Amount: " + money.format(rs.getDouble(2)) +
                                    "\n Status: " + rs.getString(3) +
                                    "\n Type: " + rs.getString(4));
                        }
                        break;
                    case "c":
                        ps = c.prepareStatement("Select lender.nameFirst, lender.nameLast, UserPhone.phoneNum, " +
                                "UserEmail.email " +
                                "From lender Inner Join UserEmail on lender.username=UserEmail.username " +
                                "Inner Join UserPhone on lender.username = UserPhone.username " +
                                "Where lender.lenderID in (Select lenderID from Borrower Inner Join Mortgage " +
                                "on borrower.borrowerID=Mortgage.borrowerID where borrower.username=?)");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Lender name: " + rs.getString(1) + " " + rs.getString(2) +
                                    "\n Phone: " + rs.getLong(3) +
                                    "\n Email: " + rs.getString(4));
                        }
                        break;
                    case "d":
                        ps = c.prepareStatement("SELECT Document.docType, LenderDoc.docStatus " +
                                "from Document Inner Join LenderDoc on Document.docID=LenderDoc.docID " +
                                "where borrowerID in (Select borrowerID from Borrower where Username = ?)");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Document Type: " + rs.getString(1) +
                                    "\n Document Status: " + rs.getString(2));
                        }
                        break;
                    case "s":
                        ps = c.prepareStatement("SELECT B.creditScore " +
                                "FROM Borrower as B " +
                                "JOIN User as U ON B.username = U.username " +
                                "WHERE U.userName = ?");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Your credit score: " + rs.getInt(1));
                        }
                        break;
                    case "p":
                        System.out.println(ui.propertyPage); // getting all the conditions
                        ArrayList<String> inputList = new ArrayList<String>();
                        input = key.next();
                        inputList.add(input);
                        System.out.println(ui.pp2);
                        input = key.next();
                        inputList.add(input);
                        System.out.println(ui.pp3);
                        input = key.next();
                        inputList.add(input);
                        System.out.println(ui.pp4);
                        input = key.next();
                        inputList.add(input);
                        System.out.println(ui.pp5);
                        input = key.next();
                        inputList.add(input);
                        System.out.println(ui.pp6);
                        input = key.next();
                        inputList.add(input);

                        ArrayList<String> whereList = new ArrayList<String>(); // setup
                        String where = "where ";
                        whereList.add("adrState = ?");
                        whereList.add("marketValue <= ?");
                        whereList.add("marketValue >= ?");
                        whereList.add("yearBuilt <= ?");
                        whereList.add("yearBuilt >= ?");
                        whereList.add("propertyType = ?");

                        if (inputList.get(0).equals("-")) { // voiding any un-needed conditions
                            whereList.set(0, "");
                        }
                        if (inputList.get(1).equals("-")) {
                            whereList.set(1, "");
                        }
                        if (inputList.get(2).equals("-")) {
                            whereList.set(2, "");
                        }
                        if (inputList.get(3).equals("-")) {
                            whereList.set(3, "");
                        }
                        if (inputList.get(4).equals("-")) {
                            whereList.set(4, "");
                        }
                        if (inputList.get(5).equals("-")) {
                            whereList.set(5, "");
                        }

                        for (String e : whereList) { // get rid of where if not needed and remove extra and at end
                            if (!e.equals("")) {
                                where = where + e + " and ";
                            }
                        }
                        if (where.equals("where ")) {
                            where = "";
                        } else {
                            where = where.substring(0, where.length() - 5);
                        }

                        ps = c.prepareStatement("select propertyID, adrStrNum, adrStrName, adrAptNum, adrState, " +
                                "adrCity, adrZip, marketValue, yearBuilt, propertyType " +
                                "from Property " +
                                where);

                        int count = 1;
                        for (int i = 0; i < 6; i++) {// put in the inputs
                            if (!whereList.get(i).equals("")) {
                                if (i == 1 || i == 2) {
                                    ps.setDouble(count, Double.parseDouble(inputList.get(i)));

                                } else if (i == 0 || i == 5) {
                                    ps.setString(count, inputList.get(i));

                                } else {
                                    ps.setInt(count, Integer.parseInt(inputList.get(i)));
                                }
                                count++;
                            }
                        }

                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n Property ID: " + rs.getInt(1) +
                                    "\n Street Number: " + rs.getInt(2) +
                                    "\n Street Name: " + rs.getString(3) +
                                    "\n Apartment Number: " + rs.getString(4) +
                                    "\n State: " + rs.getString(5) +
                                    "\n City: " + rs.getString(6) +
                                    "\n Zipcode: " + rs.getInt(7) +
                                    "\n Market Value: " + money.format(rs.getDouble(8)) +
                                    "\n Year built: " + rs.getInt(9) +
                                    "\n Type: " + rs.getString(10));
                        }
                        break;
                    case "m":
                        ps = c.prepareStatement("select mortgageID, totalLoan, startDate, endDate, InterestRate, " +
                                "FreqOfInstallments, mortgageStatus, lenderID, propertyID " +
                                "from borrower join mortgage on borrower.borrowerID = mortgage.borrowerID " +
                                "where username like ?");
                        ps.setString(1, user);
                        rs = ps.executeQuery();
                        while (rs.next()) {
                            System.out.println("\n MortgageID: " + rs.getInt(1) +
                                    "\n Status: " + rs.getString(7) +
                                    "\n Total Loan: " + money.format(rs.getDouble(2)) +
                                    "\n Interest Rate: " + rs.getInt(5) + "%" +
                                    "\n Frequency Of Installments: " + rs.getString(6) +
                                    "\n Start Date: " + rs.getString(3) +
                                    "\n End Date: " + rs.getString(4) +
                                    "\n Property ID: " + rs.getString(9) +
                                    "\n Lender ID: " + rs.getInt(8));
                        }
                        break;
                    case "l":
                        noLogout = false;
                        mainPage();
                        break;
                    case "q":
                        noQuit = false;
                        break;
                    default:
                        break;
                }

            } catch (SQLException sqle) {
                System.out.println("SQLException : " + sqle);
            }
        }
    }

    public static void EditContact() {// connect to the database
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            ResultSet rs;
            PreparedStatement ps;
            int count = 1;
            ArrayList<Long> phoneList = new ArrayList<Long>();
            ArrayList<String> emailList = new ArrayList<String>();

            System.out.println("\n" + ui.ecTitle); // print out title

            ps = c.prepareStatement("select phoneNum from userPhone where username = ?"); // get all the phone numbers
            ps.setString(1, user);

            rs = ps.executeQuery();
            while (rs.next()) {
                phoneList.add(rs.getLong(1));
                System.out.println("[" + count + "] " + rs.getLong(1));
                count++;
            }
            ps = c.prepareStatement("select email from userEmail where username = ?"); // get all the emails
            ps.setString(1, user);

            rs = ps.executeQuery();
            while (rs.next()) {
                emailList.add(rs.getString(1));
                System.out.println("[" + count + "] " + rs.getString(1));
                count++;
            }

            System.out.println("\n" + ui.ecMenu); // print out menu
            input = key.next();

            if (input.equals("b")) {
                // do nothing
            } else if (canInt(input) && Integer.parseInt(input) <= count && Integer.parseInt(input) > 0) { // if select
                int select = Integer.parseInt(input);
                if (select <= phoneList.size()) { // if phone
                    System.out.println("You have selected: [" + select + "] " + phoneList.get(select - 1));
                    System.out.println("\n" + ui.ecMenu2);
                    input = key.next();
                    if (input.equals("z")) { // delete phone
                        ps = c.prepareStatement("delete from userPhone where phoneNum = ?");
                        ps.setLong(1, phoneList.get(select - 1));
                        ps.execute();
                        System.out.println("Deletion complete");
                    } else { // new phone
                        updatePhone(phoneList, select);
                    }
                } else { // if email
                    System.out.println(
                            "You have selected: [" + select + "] " + emailList.get(select - 1 - phoneList.size()));
                    System.out.println("\n" + ui.ecMenu2);
                    input = key.next();
                    if (input.equals("z")) { // delete phone
                        deleteEmail(phoneList, emailList, select);
                    } else { // new phone
                        updateEmail(phoneList, emailList, select);
                    }
                }
            } else { // if new input
                if (input.length() == 10) { // if phone
                    newPhone();
                } else {
                    if (input.contains("@") && input.contains(".")) {
                        newEmail();
                    } else {
                        System.out.println("New email needs to be formated __@__.__ and does not already exist");
                    }

                }
            }

        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    public static boolean canInt(String in) {
        boolean can = true;
        try {
            int nIn = Integer.parseInt(in);
            nIn = nIn + 1; // this is just to get rid of the yellow highlights
        } catch (Exception e) {
            can = false;
        }
        return can;
    }

    public static void updatePhone(ArrayList<Long> phoneList, int select) {
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            PreparedStatement ps;
            ResultSet rs;
            if (input.length() == 10) {
                try {
                    int exist = 0;
                    ps = c.prepareStatement("select email from userEmail where email = ?");
                    ps.setString(1, input);
                    rs = ps.executeQuery();
                    while (rs.next()) {
                        exist++;
                    }
                    if (exist != 0) { // phone number already exists
                        throw new Exception();
                    }

                    ps = c.prepareStatement("update userPhone set phoneNum = ? where phoneNum = ?");
                    ps.setLong(1, Long.parseLong(input));
                    ps.setLong(2, phoneList.get(select - 1));
                    ps.execute();
                    System.out.println("Update complete");

                } catch (Exception e) { // input invalid
                    System.out.println("Updated phone number needs to be a 10 digit number");
                }
            } else { // input invalid
                System.out.println("Updated phone number needs to be a 10 digit number");
            }
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    public static void deleteEmail(ArrayList<Long> phoneList, ArrayList<String> emailList, int select) {
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            PreparedStatement ps;
            ps = c.prepareStatement("delete from userEmail where email = ?");
            ps.setString(1, emailList.get(select - 1 - phoneList.size()));
            ps.execute();
            System.out.println("Deletion complete");
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    public static void updateEmail(ArrayList<Long> phoneList, ArrayList<String> emailList, int select) {
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            PreparedStatement ps;
            ResultSet rs;
            if (input.length() > 4 && input.contains("@") && input.contains(".")) { // see if it already exists
                int exist = 0;
                ps = c.prepareStatement("select email from userEmail where email = ?");
                ps.setString(1, input);
                rs = ps.executeQuery();
                while (rs.next()) {
                    exist++;
                }
                if (exist == 0) { // email is new to database
                    ps = c.prepareStatement("update userEmail set email = ? where email = ?");
                    ps.setString(1, input);
                    ps.setString(2, emailList.get(select - 1 - phoneList.size()));
                    ps.execute();
                    System.out.println("Update complete");
                } else {
                    System.out.println("Updated email needs to be formated __@__.__ and does not already exist");
                }

            } else { // input invalid
                System.out.println("Updated email needs to be formated __@__.__ and does not already exist");
            }
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    public static void newPhone() {
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            PreparedStatement ps;
            ResultSet rs;
            try {
                int exist = 0;
                ps = c.prepareStatement("select phoneNum from userPhone where phoneNum = ?"); // see if it already
                                                                                              // exists
                ps.setLong(1, Long.parseLong(input));
                rs = ps.executeQuery();
                while (rs.next()) {
                    exist++;
                }
                if (exist != 0) { // phone number already exists
                    throw new Exception();
                }

                ps = c.prepareStatement("insert into userPhone values(?, ?)");
                ps.setString(1, user);
                ps.setLong(2, Long.parseLong(input));
                ps.execute();
                System.out.println("Insert complete");

            } catch (Exception e) { // input invalid
                System.out.println("New phone number needs to be a 10 digit number and does not already exist");
            }
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }

    public static void newEmail() {
        try (Connection c = DriverManager.getConnection(signIn.dbID, signIn.userID, signIn.pw);) {
            PreparedStatement ps;
            ResultSet rs;
            try {
                int exist = 0;
                ps = c.prepareStatement("select email from userEmail where email = ?"); // see if it already exists
                ps.setString(1, input);
                rs = ps.executeQuery();
                while (rs.next()) {
                    exist++;
                }
                if (exist != 0) { // email already exists
                    throw new Exception();
                }
                ps = c.prepareStatement("insert into userEmail values(?, ?)");
                ps.setString(1, user);
                ps.setString(2, input);
                ps.execute();
                System.out.println("Insert complete");

            } catch (Exception e) { // input invalid
                System.out.println("New email needs to be formated __@__.__ and does not already exist");
            }
        } catch (SQLException sqle) {
            System.out.println("SQLException : " + sqle);
        }
    }
}
