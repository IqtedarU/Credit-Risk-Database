CREATE DATABASE  IF NOT EXISTS `mortgagemanagementsystem` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mortgagemanagementsystem`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mortgagemanagementsystem
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `application`
--

DROP TABLE IF EXISTS `application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `application` (
  `appID` int NOT NULL,
  `lenderID` int NOT NULL,
  `borrowerID` int NOT NULL,
  `mortgageID` int NOT NULL,
  PRIMARY KEY (`appID`),
  KEY `lenderID` (`lenderID`),
  KEY `borrowerID` (`borrowerID`),
  KEY `mortgageID` (`mortgageID`),
  CONSTRAINT `application_ibfk_1` FOREIGN KEY (`lenderID`) REFERENCES `lender` (`lenderID`),
  CONSTRAINT `application_ibfk_2` FOREIGN KEY (`borrowerID`) REFERENCES `borrower` (`borrowerID`),
  CONSTRAINT `application_ibfk_3` FOREIGN KEY (`mortgageID`) REFERENCES `mortgage` (`mortgageID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `application`
--

LOCK TABLES `application` WRITE;
/*!40000 ALTER TABLE `application` DISABLE KEYS */;
INSERT INTO `application` VALUES (1,1,1,1),(2,2,2,2),(3,3,3,3),(4,4,4,4),(5,5,5,5),(6,6,6,6),(7,7,7,7),(8,8,8,8),(9,9,9,9),(10,10,10,10),(11,11,11,11),(12,12,12,12),(13,13,13,13),(14,14,14,14),(15,15,15,15),(16,16,16,16),(17,17,17,17),(18,18,18,18),(19,19,19,19),(20,20,20,20),(21,21,21,21),(22,22,22,22),(23,23,23,23),(24,24,24,24),(25,25,25,25),(26,26,26,25),(27,27,26,25),(28,27,27,25),(29,27,27,25);
/*!40000 ALTER TABLE `application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `borrower`
--

DROP TABLE IF EXISTS `borrower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `borrower` (
  `borrowerID` int NOT NULL,
  `nameFirst` varchar(25) NOT NULL,
  `nameLast` varchar(25) NOT NULL,
  `userType` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  `creditScore` int NOT NULL,
  `annualIncome` decimal(8,2) NOT NULL,
  `employmentStatus` varchar(25) NOT NULL,
  `dateOfBirth` varchar(25) NOT NULL,
  `SSN` int NOT NULL,
  PRIMARY KEY (`borrowerID`),
  KEY `username` (`username`),
  CONSTRAINT `borrower_ibfk_1` FOREIGN KEY (`username`) REFERENCES `user` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `borrower`
--

LOCK TABLES `borrower` WRITE;
/*!40000 ALTER TABLE `borrower` DISABLE KEYS */;
INSERT INTO `borrower` VALUES (1,'Phyllis','Bonilla','borrower','546bre54','CheezeSteak',630,103632.00,'employed','11/18/1974',316427459),(2,'Jack','Tanner','borrower','br54re56','Draho',490,42158.00,'employed','6/21/1975',764129921),(3,'Emmanuel','Blake','borrower','546beb54bb','Blake',832,0.00,'unemployed','1/10/1981',678253916),(4,'Toney','Durham','borrower','546breae','HoneyTea',760,324576.00,'employed','5/9/1981',376945865),(5,'Josue','Pratt','borrower','abere564b6','JPratt',597,261563.00,'employed','11/20/1981',312965372),(6,'Noelle','Strickland','borrower','bdf5a6bdf56','NeedLand',445,0.00,'unemployed','8/29/1982',521034906),(7,'Xavier','Burgess','borrower','546breen','Xaliber',320,43618.00,'employed','7/9/1983',701346095),(8,'Charles','Lucas','borrower','78ew3br','Lucas',621,94813.00,'employed','12/18/1990',951375642),(9,'Giuseppe','Barker','borrower','32bdfre','BakerG',791,68381.00,'employed','9/19/1991',973451620),(10,'Al','Stuart','borrower','56ewv','Intelain',675,0.00,'unemployed','7/18/1997',603420619),(11,'Queen','Travis','borrower','12aer','ImQueen',834,0.00,'unemployed','10/18/1965',130245796),(12,'Marcos','Bright','borrower','nklewkj32','NeedBright',647,97324.00,'employed','7/11/1971',249167546),(13,'Emmett','Gross','borrower','tne3ew','EGross',757,54156.00,'employed','10/15/1973',653057948),(14,'Earl','Downs','borrower','9488ymrc','Downs4Land',672,187214.00,'employed','1/2/1978',431672056),(15,'Myrna','Howell','borrower','2s58v1fbd','Mymy',784,57980.00,'employed','2/3/1981',376419028),(16,'Bonita','Hensley','borrower','nbyud4b74gf','BeautyHen',325,96049.00,'employed','10/6/1982',976475182),(17,'Fermin','Parrish','borrower','nfhjv5djbn','FPneedC',642,95742.00,'employed','1/7/1984',296372514),(18,'Reva','Frazier','borrower','44fht','Freezer',762,0.00,'unemployed','8/21/1990',885436960),(19,'Miquel','Ball','borrower','75eyhvnegh','RollingHoem',641,56054.00,'employed','9/11/1990',955543020),(20,'Maria','Hudson','borrower','yhmre962dh','Bloomer',774,54660.00,'employed','5/8/1997',600315044),(21,'Nona','Cisneros','borrower','hbke5b','NCis',845,260466.00,'employed','6/24/1965',765400245),(22,'Aubrey','Myers','borrower','5nhje','AMyers',821,42054.00,'employed','3/31/1969',316004250),(23,'Tara','Gamble','borrower','iwmnvtgf6','Skullbloom',514,97100.00,'employed','4/14/1973',113460570),(24,'Sid','Le','borrower','uifn5fuf','SydneyBlues',845,94205.00,'employed','10/4/1986',573160004),(25,'Randall','Levy','borrower','rev97258','Lev',725,132450.00,'employed','5/16/1990',600134500),(26,'Gavin','White','borrower','hjf478jv','LibrarySe',764,90742.00,'employed','9/11/1992',970067076),(27,'Shane','Green','borrower','54eyuv','GreenTrees',785,82053.00,'employed','7/27/1993',331246384),(28,'Darwin','Gibbs','borrower','bjivie54','HomesEvo',424,126160.00,'employed','12/26/1995',990643009),(29,'Sophia','Pena','borrower','726fju','FloraBloom',745,0.00,'unemployed','2/26/1996',789006512),(30,'Jack','Hawkins','borrower','rtghnew58','Olantern',475,0.00,'unemployed','9/24/1996',978460500),(31,'Alex','Gamble','borrower','91bube','Cactux4U',456,92541.00,'employed','1/9/2000',300240011),(32,'John','Parker','borrower','oiwhj41','Spidy',751,190146.00,'employed','2/22/1972',555623410),(33,'Lucas','Earl','borrower','jrgew98','Luke',642,74112.00,'employed','7/30/1976',100004275);
/*!40000 ALTER TABLE `borrower` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `docID` int NOT NULL,
  `docType` varchar(25) NOT NULL,
  `borrowerID` int NOT NULL,
  `appID` int NOT NULL,
  PRIMARY KEY (`docID`),
  KEY `borrowerID` (`borrowerID`),
  KEY `appID` (`appID`),
  CONSTRAINT `document_ibfk_1` FOREIGN KEY (`borrowerID`) REFERENCES `borrower` (`borrowerID`),
  CONSTRAINT `document_ibfk_2` FOREIGN KEY (`appID`) REFERENCES `application` (`appID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
INSERT INTO `document` VALUES (1,'income verification ',1,1),(2,'asset doc',1,1),(3,' income verification',1,1),(4,'employment verification ',1,1),(5,'credit history ',1,1),(6,'identification doc',1,1),(7,'income verification ',2,2),(8,'asset doc',2,2),(9,' income verification',2,2),(10,'employment verification ',2,2),(11,'credit history ',2,2),(12,'identification doc',2,2),(13,'income verification ',3,3),(14,'asset doc',3,3),(15,' income verification',3,3),(16,'employment verification ',3,3),(17,'credit history ',3,3),(18,'identification doc',3,3),(19,'income verification ',4,4),(20,'asset doc',4,4),(21,' income verification',4,4),(22,'employment verification ',4,4),(23,'credit history ',4,4),(24,'identification doc',4,4),(25,'income verification ',5,5),(26,'asset doc',5,5),(27,' income verification',5,5),(28,'employment verification ',5,5),(29,'credit history ',5,5),(30,'identification doc',5,5),(31,'income verification ',6,6),(32,'asset doc',6,6),(33,' income verification',6,6),(34,'employment verification ',6,6),(35,'credit history ',6,6),(36,'identification doc',6,6),(37,'income verification ',26,26),(38,'asset doc',26,26),(39,' income verification',27,27),(40,'employment verification ',27,28),(41,'credit history ',27,28);
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `escrow`
--

DROP TABLE IF EXISTS `escrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `escrow` (
  `escrowID` int NOT NULL,
  `dateEscrowed` varchar(25) NOT NULL,
  PRIMARY KEY (`escrowID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `escrow`
--

LOCK TABLES `escrow` WRITE;
/*!40000 ALTER TABLE `escrow` DISABLE KEYS */;
INSERT INTO `escrow` VALUES (1,'1/1/2016'),(2,'2/1/2016'),(3,'3/1/2016'),(4,'4/1/2016'),(5,'7/7/2017'),(6,'5/8/2016'),(7,'6/12/2016'),(8,'6/1/2016'),(9,'6/2/2016'),(10,'6/3/2016'),(11,'6/4/2016'),(12,'12/1/2019'),(13,'6/6/2016'),(14,'6/7/2016'),(15,'6/8/2016'),(16,'7/7/2018'),(17,'6/6/2016'),(18,'7/7/2017'),(19,'6/9/2020'),(20,'2/2/2016'),(21,'6/5/2016'),(22,'6/5/2016'),(23,'9/1/2021'),(24,'7/1/2021'),(25,'6/1/2016'),(26,'7/2/2016'),(27,'11/1/2022'),(28,'1/12/2017'),(29,'2/1/2022'),(30,'3/1/2022'),(31,'4/1/2022'),(32,'4/2/2022'),(33,'4/3/2022');
/*!40000 ALTER TABLE `escrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lender`
--

DROP TABLE IF EXISTS `lender`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lender` (
  `lenderID` int NOT NULL,
  `nameFirst` varchar(25) NOT NULL,
  `nameLast` varchar(25) NOT NULL,
  `userType` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `username` varchar(25) NOT NULL,
  PRIMARY KEY (`lenderID`),
  KEY `username` (`username`),
  CONSTRAINT `lender_ibfk_1` FOREIGN KEY (`username`) REFERENCES `user` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lender`
--

LOCK TABLES `lender` WRITE;
/*!40000 ALTER TABLE `lender` DISABLE KEYS */;
INSERT INTO `lender` VALUES (1,'Margery','Gay','lender','ndhc8ju8','MarsIsGray'),(2,'Cesar','Stokes','lender','pv6dx7w87k','RomanHome'),(3,'Zackary','Crosby','lender','mnvjeu883hc8','zzz777'),(4,'Diane','Horton','lender','648h7cg2','Rosei'),(5,'Letitia','Bridges','lender','nfuiebicy9','HomeBridge'),(6,'Houston','Lozano','lender','v46v58edv','HouseTon'),(7,'Nolan','Wolfe','lender','xcbe3','WolvesDen'),(8,'Leopoldo','Krueger','lender','ez5i2dilwr','Lepord'),(9,'Krystal','Rojas','lender','638dfhv7rb','Sparkles'),(10,'Caroline','Bryant','lender','nbosghnxeq6','Coral'),(11,'Letha','Mccall','lender','beuv6729bvyu','Lethander'),(12,'Andrea','Gibbs','lender','bneui729c','GibbsLend'),(13,'Julie','Hubbard','lender','flvbkgmmy6','Bestbard'),(14,'Deanne','Valentine','lender','he7362nc8','Gfam4U'),(15,'Robyn','Hayden','lender','mgi3782d','BerbinCow'),(16,'Bryan','Gregory','lender','648dbvt','BestDeal'),(17,'Alma','Taylor','lender','bi2389g1','TamlaL'),(18,'Carlos','Rivas','lender','bidv782','FreeBank'),(19,'Sheldon','Dougherty','lender','i8723vsd','MarchDot14'),(20,'Dean','Murphy','lender','bswvi3135','Dean'),(21,'Leonard','Contreras','lender','bhfe79','Leo'),(22,'Mervin','matthews','lender','t78bj2','MageMervin'),(23,'Alisa','Mitchell','lender','789v329d','LisaM'),(24,'Julia','Boyd','lender','bidvsui89','yaBoyd'),(25,'Colin','Bishop','lender','bi89vdbj','Camel'),(26,'Josie','Mcmillan','lender','ohuvew3','Mcmillans'),(27,'Stephan','Hunter','lender','8923bkjv89','SHunter');
/*!40000 ALTER TABLE `lender` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lenderdoc`
--

DROP TABLE IF EXISTS `lenderdoc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lenderdoc` (
  `lenderID` int NOT NULL,
  `docID` int NOT NULL,
  `docStatus` varchar(25) NOT NULL,
  PRIMARY KEY (`lenderID`,`docID`),
  KEY `docID` (`docID`),
  CONSTRAINT `lenderdoc_ibfk_1` FOREIGN KEY (`lenderID`) REFERENCES `lender` (`lenderID`),
  CONSTRAINT `lenderdoc_ibfk_2` FOREIGN KEY (`docID`) REFERENCES `document` (`docID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lenderdoc`
--

LOCK TABLES `lenderdoc` WRITE;
/*!40000 ALTER TABLE `lenderdoc` DISABLE KEYS */;
INSERT INTO `lenderdoc` VALUES (1,1,'approved'),(1,2,'approved'),(1,3,'approved'),(1,4,'approved'),(1,5,'approved'),(1,6,'approved'),(2,7,'approved'),(2,8,'approved'),(2,9,'approved'),(2,10,'approved'),(2,11,'approved'),(2,12,'approved '),(3,13,'approved '),(3,14,'approved'),(3,15,'approved'),(3,16,'approved'),(3,17,'approved'),(3,18,'approved'),(4,19,'approved'),(4,20,'approved'),(4,21,'approved'),(4,22,'approved '),(4,23,'approved '),(4,24,'approved'),(5,25,'approved'),(5,26,'approved'),(5,27,'approved '),(5,28,'approved '),(5,29,'approved '),(5,30,'approved '),(6,31,'approved '),(6,32,'approved '),(6,33,'approved '),(6,34,'approved '),(6,35,'approved '),(6,36,'approved '),(26,37,'pending'),(26,38,'pending'),(27,39,'denied'),(27,40,'approved'),(27,41,'denied');
/*!40000 ALTER TABLE `lenderdoc` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lenderescrow`
--

DROP TABLE IF EXISTS `lenderescrow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lenderescrow` (
  `lenderID` int NOT NULL,
  `escrowID` int NOT NULL,
  `dateSent` varchar(25) NOT NULL,
  PRIMARY KEY (`lenderID`,`escrowID`),
  KEY `escrowID` (`escrowID`),
  CONSTRAINT `lenderescrow_ibfk_1` FOREIGN KEY (`lenderID`) REFERENCES `lender` (`lenderID`),
  CONSTRAINT `lenderescrow_ibfk_2` FOREIGN KEY (`escrowID`) REFERENCES `escrow` (`escrowID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lenderescrow`
--

LOCK TABLES `lenderescrow` WRITE;
/*!40000 ALTER TABLE `lenderescrow` DISABLE KEYS */;
INSERT INTO `lenderescrow` VALUES (1,1,'1/6/2016'),(1,28,'1/17/2017'),(2,2,'2/6/2016'),(3,3,'3/6/2016'),(3,29,'2/6/2022'),(4,4,'4/6/2016'),(5,5,'7/12/2017'),(5,30,'3/6/2022'),(6,6,'5/13/2016'),(7,7,'6/17/2016'),(7,31,'4/6/2022'),(8,8,'6/6/2016'),(9,9,'6/7/2016'),(9,32,'4/7/2022'),(10,10,'6/8/2016'),(11,11,'6/9/2016'),(11,33,'4/8/2022'),(12,10,'12/6/2019'),(13,13,'6/11/2016'),(14,14,'6/12/2016'),(15,15,'6/13/2016'),(16,16,'7/12/2018'),(17,17,'6/11/2016'),(18,18,'7/12/2017'),(19,19,'6/14/2020'),(20,20,'2/7/2016'),(21,21,'6/10/2016'),(22,22,'6/10/2016'),(23,23,'9/6/2021'),(24,24,'7/6/2021'),(25,25,'6/6/2016'),(26,26,'7/7/2016'),(27,27,'11/6/2022');
/*!40000 ALTER TABLE `lenderescrow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mortgage`
--

DROP TABLE IF EXISTS `mortgage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mortgage` (
  `mortgageID` int NOT NULL,
  `totalLoan` int NOT NULL,
  `startDate` varchar(25) NOT NULL,
  `endDate` varchar(25) NOT NULL,
  `InterestRate` int NOT NULL,
  `FreqOfInstallments` varchar(25) NOT NULL,
  `mortgageStatus` varchar(25) NOT NULL,
  `lenderID` int NOT NULL,
  `borrowerID` int NOT NULL,
  `propertyID` int NOT NULL,
  PRIMARY KEY (`mortgageID`),
  KEY `lenderID` (`lenderID`),
  KEY `borrowerID` (`borrowerID`),
  KEY `propertyID` (`propertyID`),
  CONSTRAINT `mortgage_ibfk_1` FOREIGN KEY (`lenderID`) REFERENCES `lender` (`lenderID`),
  CONSTRAINT `mortgage_ibfk_2` FOREIGN KEY (`borrowerID`) REFERENCES `borrower` (`borrowerID`),
  CONSTRAINT `mortgage_ibfk_3` FOREIGN KEY (`propertyID`) REFERENCES `property` (`propertyID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mortgage`
--

LOCK TABLES `mortgage` WRITE;
/*!40000 ALTER TABLE `mortgage` DISABLE KEYS */;
INSERT INTO `mortgage` VALUES (1,250000,'10/20/2015','1/1/2025',5,'Monthly','Active',1,1,1),(2,250000,'10/21/2015','1/2/2025',10,'Monthly','Active',2,2,2),(3,250000,'10/22/2015','1/3/2025',3,'Monthly','Active',3,3,3),(4,250000,'10/23/2015','1/4/2025',5,'Monthly','Active',4,4,4),(5,250000,'10/24/2015','1/5/2025',5,'Monthly','Active',5,5,5),(6,250000,'10/25/2015','1/6/2025',5,'Monthly','Active',6,6,6),(7,100000,'10/26/2015','1/7/2025',5,'Monthly','Active',7,7,7),(8,100000,'10/27/2015','1/8/2025',5,'Monthly','Active',8,8,8),(9,100000,'10/28/2015','1/9/2025',10,'Monthly','Active',9,9,9),(10,100000,'10/29/2015','1/10/2025',1,'Monthly','Active',10,10,10),(11,100000,'10/30/2015','1/11/2025',10,'Monthly','Active',11,11,11),(12,100000,'10/31/2015','1/12/2025',10,'Monthly','Active',12,12,12),(13,300000,'11/1/2015','1/13/2025',13,'Monthly','Active',13,13,13),(14,300000,'11/2/2015','1/14/2025',5,'Monthly','Active',14,14,14),(15,300000,'11/3/2015','1/15/2025',5,'Monthly','Active',15,15,15),(16,300000,'11/4/2015','1/16/2025',3,'Monthly','Active',16,16,16),(17,300000,'11/5/2015','1/17/2025',3,'Monthly','Active',17,17,17),(18,300000,'11/6/2015','1/18/2025',7,'Monthly','Active',18,18,18),(19,300000,'11/7/2015','1/19/2025',3,'Monthly','Active',19,19,19),(20,500000,'11/8/2015','1/20/2025',3,'Monthly','Active',20,20,20),(21,500000,'11/9/2015','1/21/2025',3,'Monthly','Active',21,21,21),(22,500000,'11/10/2015','1/22/2025',3,'Monthly','Active',22,22,22),(23,500000,'11/11/2015','1/23/2025',5,'Monthly','Active',23,23,23),(24,500000,'11/12/2015','1/24/2025',3,'Monthly','Active',24,24,24),(25,500000,'11/13/2015','1/25/2025',3,'Monthly','Active',25,25,25);
/*!40000 ALTER TABLE `mortgage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment` (
  `paymentID` int NOT NULL,
  `dateOfPayment` varchar(25) NOT NULL,
  `amountPaid` decimal(8,2) NOT NULL,
  `statusOfPayment` varchar(25) NOT NULL,
  `paymentType` varchar(25) NOT NULL,
  `borrowerID` int NOT NULL,
  `mortgageID` int NOT NULL,
  `escrowID` int NOT NULL,
  PRIMARY KEY (`paymentID`),
  KEY `borrowerID` (`borrowerID`),
  KEY `mortgageID` (`mortgageID`),
  KEY `escrowID` (`escrowID`),
  CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`borrowerID`) REFERENCES `borrower` (`borrowerID`),
  CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`mortgageID`) REFERENCES `mortgage` (`mortgageID`),
  CONSTRAINT `payment_ibfk_3` FOREIGN KEY (`escrowID`) REFERENCES `escrow` (`escrowID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'1/1/2016',3843.60,'approved','credit card',1,1,1),(2,'2/1/2016',6284.75,'approved','credit card',1,1,1),(3,'3/1/2016',1985.59,'approved','credit card',1,1,1),(4,'4/1/2016',2222.85,'pending','credit card',1,1,1),(5,'7/7/2017',2923.85,'approved','check',2,2,2),(6,'5/8/2016',7519.96,'declined','check',2,2,2),(7,'6/12/2016',3156.27,'approved','credit card',3,3,3),(8,'6/1/2016',2325.00,'approved','credit card',4,4,4),(9,'6/2/2016',1063.58,'approved','credit card',5,5,5),(10,'6/3/2016',7219.55,'approved','credit card',6,6,6),(11,'6/4/2016',3834.26,'approved','credit card',7,7,7),(12,'12/1/2019',6160.22,'approved','check',8,8,8),(13,'6/6/2016',3679.96,'pending','check',9,9,9),(14,'6/7/2016',4887.99,'pending','check',10,10,10),(15,'6/8/2016',4040.99,'pending','check',11,11,11),(16,'7/7/2018',5935.32,'declined','check',12,12,12),(17,'6/6/2016',5811.96,'declined','credit card',13,13,13),(18,'7/7/2017',6101.70,'pending','credit card',14,14,14),(19,'6/9/2020',6471.67,'approved','credit card',15,15,15),(20,'2/2/2016',4269.69,'approved','credit card',16,16,16),(21,'6/5/2016',7636.88,'approved','credit card',17,17,17),(22,'6/5/2016',3768.12,'approved','check',18,18,18),(23,'9/1/2021',1360.10,'approved','check',19,19,19),(24,'7/1/2021',4350.97,'approved','credit card',20,20,20),(25,'6/1/2016',4964.24,'approved','credit card',21,21,21),(26,'7/2/2016',1570.69,'approved','check',22,22,22),(27,'11/1/2022',984.76,'approved','credit card',23,23,23),(28,'1/12/2017',6328.66,'approved','credit card',24,24,24),(29,'2/1/2022',3630.74,'approved','credit card',25,25,25),(30,'3/1/2022',6252.51,'approved','credit card',25,25,25),(31,'4/1/2022',4963.11,'declined','check',25,25,25),(32,'4/2/2022',1977.09,'declined','credit card',25,25,25),(33,'4/3/2022',5728.47,'pending','credit card',25,25,25);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `property`
--

DROP TABLE IF EXISTS `property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `property` (
  `propertyID` int NOT NULL,
  `adrStrNum` int NOT NULL,
  `adrStrName` varchar(25) NOT NULL,
  `adrAptNum` varchar(4) DEFAULT NULL,
  `adrState` varchar(2) NOT NULL,
  `adrCity` varchar(25) NOT NULL,
  `adrZip` int NOT NULL,
  `marketValue` decimal(8,2) NOT NULL,
  `yearBuilt` int NOT NULL,
  `propertyType` varchar(25) NOT NULL,
  `lenderID` int NOT NULL,
  `borrowerID` int NOT NULL,
  PRIMARY KEY (`propertyID`),
  KEY `lenderID` (`lenderID`),
  KEY `borrowerID` (`borrowerID`),
  CONSTRAINT `property_ibfk_1` FOREIGN KEY (`lenderID`) REFERENCES `lender` (`lenderID`),
  CONSTRAINT `property_ibfk_2` FOREIGN KEY (`borrowerID`) REFERENCES `borrower` (`borrowerID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `property`
--

LOCK TABLES `property` WRITE;
/*!40000 ALTER TABLE `property` DISABLE KEYS */;
INSERT INTO `property` VALUES (1,123,'Main St','4A','NY','New York',10001,300000.00,2000,'Condo',1,1),(2,456,'Oak Dr','','CA','Los Angeles ',10003,200000.00,1950,'Single Family',2,2),(3,789,'Pine Ave','12B','IL','Chicago',90003,300000.00,1970,'Single Family',3,3),(4,321,'Elm St','','TX','Austin',56978,200000.00,2010,'Condo',4,4),(5,654,'Maple Ln','3C','AZ','Phoenix',67895,450000.00,2010,'Condo',5,5),(6,987,'Cedar Rd','','PA','Philadelphia',65432,300000.00,2020,'Condo',6,6),(7,135,'Birch St','5D','TX','San Antonio',11234,450000.00,2021,'Condo',7,7),(8,246,'Walnut Dr','','CA','Los Angeles ',45367,200000.00,1983,'Condo',8,8),(9,357,'Willow Ave','6E','TX','Austin',56786,500000.00,2022,'Single Family',9,9),(10,468,'Spruce Ave','','CA','San deigo',56567,450000.00,2017,'Single Family',10,10),(11,579,'Cherry Rd','7F','TX','Dallas',44531,500000.00,2016,'Condo',11,11),(12,680,'Peach St','','CA','San Deigo',11445,750000.00,2013,'Single Family',12,12),(13,791,'Plum Dr','8G','TX','Dallas',36890,300000.00,2011,'Condo',13,13),(14,802,'Pear Ave','','FL','Orlando',92101,450000.00,2001,'Single Family',14,14),(15,913,'Apple Ln','9H','CA','Los Angeles ',12307,500000.00,2002,'Single Family',15,15),(16,24,'Lemon Rd','','IN','Indianapolis',56027,550000.00,2002,'Single Family',16,16),(17,135,'Lime St','10I','OH','Columbus',78795,450000.00,2002,'Condo',17,17),(18,246,'Grape Dr','','TX','Austin',77664,500000.00,2004,'Single Family',18,18),(19,357,'Strawberry Ave','11J','NC','Charlotte',33110,800000.00,2003,'Condo',19,19),(20,468,'Raspberry Ln','','MI','Detroit',90012,800000.00,1982,'Single Family',20,20),(21,579,'Blueberry Rd','12K','TX','El Paso',66110,300000.00,1999,'Condo',21,21),(22,680,'Blackberry St','','WA','Seattle',90312,450000.00,1973,'Single Family',22,22),(23,791,'Cranberry Dr','13L','CO','Denver',12345,500000.00,2002,'Condo',23,23),(24,802,'Kiwi Ave','','DC','Washington',56789,450000.00,2001,'Condo',24,24),(25,913,'Mango Ln','14M','MD','Baltimore',9876,300000.00,2001,'Single Family',25,25);
/*!40000 ALTER TABLE `property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `username` varchar(25) NOT NULL,
  `nameFirst` varchar(25) NOT NULL,
  `nameLast` varchar(25) NOT NULL,
  `userType` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('AMyers','Aubrey','Myers','borrower','5nhje'),('BakerG','Giuseppe','Barker','borrower','32bdfre'),('BeautyHen','Bonita','Hensley','borrower','nbyud4b74gf'),('BerbinCow','Robyn','Hayden','lender','mgi3782d'),('Bestbard','Julie','Hubbard','lender','flvbkgmmy6'),('BestDeal','Bryan','Gregory','lender','648dbvt'),('Blake','Emmanuel','Blake','borrower','546beb54bb'),('Bloomer','Maria','Hudson','borrower','yhmre962dh'),('Cactux4U','Alex','Gamble','borrower','91bube'),('Camel','Colin','Bishop','lender','bi89vdbj'),('CheezeSteak','Phyllis','Bonilla','borrower','546bre54'),('Coral','Caroline','Bryant','lender','nbosghnxeq6'),('Dean','Dean','Murphy','lender','bswvi3135'),('Downs4Land','Earl','Downs','borrower','9488ymrc'),('Draho','Jack','Tanner','borrower','br54re56'),('EGross','Emmett','Gross','borrower','tne3ew'),('FloraBloom','Sophia','Pena','borrower','726fju'),('FPneedC','Fermin','Parrish','borrower','nfhjv5djbn'),('FreeBank','Carlos','Rivas','lender','bidv782'),('Freezer','Reva','Frazier','borrower','44fht'),('Gfam4U','Deanne','Valentine','lender','he7362nc8'),('GibbsLend','Andrea','Gibbs','lender','bneui729c'),('GreenTrees','Shane','Green','borrower','54eyuv'),('HomeBridge','Letitia','Bridges','lender','nfuiebicy9'),('HomesEvo','Darwin','Gibbs','borrower','bjivie54'),('HoneyTea','Toney','Durham','borrower','546breae'),('HouseTon','Houston','Lozano','lender','v46v58edv'),('ImQueen','Queen','Travis','borrower','12aer'),('Intelain','Al','Stuart','borrower','56ewv'),('JPratt','Josue','Pratt','borrower','abere564b6'),('Leo','Leonard','Contreras','lender','bhfe79'),('Lepord','Leopoldo','Krueger','lender','ez5i2dilwr'),('Lethander','Letha','Mccall','lender','beuv6729bvyu'),('Lev','Randall','Levy','borrower','rev97258'),('LibrarySe','Gavin','White','borrower','hjf478jv'),('LisaM','Alisa','Mitchell','lender','789v329d'),('Lucas','Charles','Lucas','borrower','78ew3br'),('Luke','Lucas','Earl','borrower','jrgew98'),('MageMervin','Mervin','matthews','lender','t78bj2'),('MarchDot14','Sheldon','Dougherty','lender','i8723vsd'),('MarsIsGray','Margery','Gay','lender','ndhc8ju8'),('Mcmillans','Josie','Mcmillan','lender','ohuvew3'),('Mymy','Myrna','Howell','borrower','2s58v1fbd'),('NCis','Nona','Cisneros','borrower','hbke5b'),('NeedBright','Marcos','Bright','borrower','nklewkj32'),('NeedLand','Noelle','Strickland','borrower','bdf5a6bdf56'),('Olantern','Jack','Hawkins','borrower','rtghnew58'),('RollingHoem','Miquel','Ball','borrower','75eyhvnegh'),('RomanHome','Cesar','Stokes','lender','pv6dx7w87k'),('Rosei','Diane','Horton','lender','648h7cg2'),('SHunter','Stephan','Hunter','lender','8923bkjv89'),('Skullbloom','Tara','Gamble','borrower','iwmnvtgf6'),('Sparkles','Krystal','Rojas','lender','638dfhv7rb'),('Spidy','John','Parker','borrower','oiwhj41'),('SydneyBlues','Sid','Le','borrower','uifn5fuf'),('TamlaL','Alma','Taylor','lender','bi2389g1'),('WolvesDen','Nolan','Wolfe','lender','xcbe3'),('Xaliber','Xavier','Burgess','borrower','546breen'),('yaBoyd','Julia','Boyd','lender','bidvsui89'),('zzz777','Zackary','Crosby','lender','mnvjeu883hc8');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `useremail`
--

DROP TABLE IF EXISTS `useremail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `useremail` (
  `username` varchar(25) NOT NULL,
  `email` varchar(25) NOT NULL,
  PRIMARY KEY (`username`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `useremail`
--

LOCK TABLES `useremail` WRITE;
/*!40000 ALTER TABLE `useremail` DISABLE KEYS */;
INSERT INTO `useremail` VALUES ('AMyers','oyqebkjx@gmail.com'),('BakerG','546v546@gmail.com'),('BakerG','6vwe56v@gmail.com'),('BerbinCow','npziw@gmail.com'),('BerbinCow','nv0epq@gmail.com'),('Blake','6ew6@gmail.com'),('Bloomer','boiew68@gmail.com'),('Cactux4U','15qwfev@gmail.com'),('Camel','nb9ve@gmail.com'),('CheezeSteak','4e568e8@gmail.com'),('CheezeSteak','ebhidvs@gmail.com'),('Coral','03b0vbeu@gmail.com'),('Coral','0923ru@gmail.com'),('Dean','bg933veu@gmail.com'),('Downs4Land','mlpikwlu@gmail.com'),('Draho','5wa57ve@gmail.com'),('FPneedC','5da75b@gmail.com'),('FreeBank','anb9ve@gmail.com'),('Freezer','ygu54@gmail.com'),('Gfam4U','bnv9ebn@gmail.com'),('GibbsLend','nbv9e4@gmail.com'),('GreenTrees','bgie668@gmail.com'),('HomeBridge','bvtdb47@gmail.com'),('HomesEvo','9q7ew8b156@gmail.com'),('HomesEvo','lmpweih18@gmail.com'),('HoneyTea','565569@gmail.com'),('HouseTon','lmvu@gmail.com'),('HouseTon','oievbhv90@gmail.com'),('ImQueen','ui689d@gmail.com'),('Intelain','468e68vv@gmail.com'),('Intelain','v68vs768@gmail.com'),('LibrarySe','wbno@gmail.com'),('Lucas','pqoix57@gmail.com'),('Lucas','qzgaipmw@gmail.com'),('Luke','prnibe574@gmail.com'),('MarchDot14','bv94bdpiq@gmail.com'),('MarsIsGray','nb084np@gmail.com'),('MarsIsGray','nv0e32@gmail.com'),('MarsIsGray','pqitvb@gmail.com'),('Mcmillans','tzjqab@gmail.com'),('NCis','nbi2564ve@gmail.com'),('NeedBright','75br4@gmail.com'),('NeedBright','w5bra@gmail.com'),('NeedLand','plqnov274@gmail.com'),('RomanHome','coiwiy@gmail.com'),('Skullbloom','bvie35@gmail.com'),('Skullbloom','nboq@gmail.com'),('Skullbloom','nobrag5@gmail.com'),('SydneyBlues','oi2v89@gmail.com'),('SydneyBlues','rghnwi4@gmail.com'),('WolvesDen','04963254ds@gmail.com'),('WolvesDen','jvoeg@gmail.com'),('yaBoyd','90vj4@gmail.com'),('yaBoyd','nv938nhg@gmail.com'),('zzz777','nvpwev@gmail.com');
/*!40000 ALTER TABLE `useremail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userphone`
--

DROP TABLE IF EXISTS `userphone`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userphone` (
  `username` varchar(25) NOT NULL,
  `phoneNum` bigint NOT NULL,
  PRIMARY KEY (`username`,`phoneNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userphone`
--

LOCK TABLES `userphone` WRITE;
/*!40000 ALTER TABLE `userphone` DISABLE KEYS */;
INSERT INTO `userphone` VALUES ('AMyers',9763152460),('BakerG',8315209004),('BeautyHen',9345504671),('Bestbard',7450410455),('BestDeal',1205536543),('Blake',9672138520),('Cactux4U',4097941971),('Camel',7452145982),('Coral',5015504582),('Coral',9542212101),('EGross',5420350540),('EGross',9847312001),('FloraBloom',1196431601),('FloraBloom',9736150801),('FPneedC',9417350957),('FPneedC',9672451200),('FreeBank',1144557200),('Freezer',6129410061),('Freezer',9431002123),('Gfam4U',4521482620),('HomesEvo',1498130541),('HomesEvo',9872196746),('HoneyTea',6240916354),('HoneyTea',7463569241),('HouseTon',9482100310),('ImQueen',3768135203),('ImQueen',6137286423),('ImQueen',9177216486),('Intelain',9436118194),('JPratt',5450842051),('JPratt',9768254154),('Leo',9985449101),('Lepord',8524986200),('Lethander',8512481747),('Lev',9726719162),('LisaM',5874159621),('Luke',4562150210),('Luke',6100681414),('Luke',9245010510),('MageMervin',1415001446),('Mymy',9761520671),('NCis',6106581320),('Olantern',8756841098),('RollingHoem',4001469291),('RomanHome',4851441125),('RomanHome',9865986210),('Rosei',4520486396),('SHunter',9245041044),('Skullbloom',4132045045),('Skullbloom',5462145105),('Sparkles',1500464103),('Sparkles',7504604205),('Spidy',9729053134),('Spidy',9842904941),('SydneyBlues',3581054204),('TamlaL',2014851440),('WolvesDen',1968102540),('Xaliber',9541186102),('zzz777',4520044561);
/*!40000 ALTER TABLE `userphone` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mortgagemanagementsystem'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-05 17:27:19
